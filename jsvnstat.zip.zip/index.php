<?php
	require 'settings.php';
	$interfaces = getAvailableInterfaces();
	$interface = getFromArgOrCookie('interface', $interface, $interfaces);
	$lines = explode("\n", getCmdOutput("vnstat --dumpdb -i $interface"));
	$info = array(); $hour = array(); $day = array(); $month = array(); $top10 = array();
	$current_hour = date("G");
	foreach ($lines as $line) {
		$line = explode(";", $line);
		switch ($line[0]) {
			case "d": $day[$line[1]] = $line; break;
			case "m": $month[$line[1]] =  $line; break;
			case "t": $top10[$line[1]] = $line; break;
			case "h": $hour[(24 - $line[1] + $current_hour)%24] = $line; break;
			default:  $info[$line[0]] = $line[1];
		}
	}
?>
<!DOCTYPE html>
<html>		
	<head>
		<link rel="shortcut icon" href="images/favicon.png" type="image/png">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>KODI traffic</title>
		<br/><h2 align="right">Traffic statistics&nbsp</h2>		
		<link href="css/default.css" rel="stylesheet" type="text/css"/>
		<script language="javascript" type="text/javascript" src="js/jquery.min.js"></script>
		<script language="javascript" type="text/javascript" src="js/jquery.flot.min.js"></script>
		<script language="javascript" type="text/javascript" src="js/radio.js"></script>
		<script language="javascript" type="text/javascript" src="js/main.js"></script>
		<script language="javascript" type="text/javascript">
			datasets = {
				"hoursrx":  {label: "RX, KB", color: "<?=$rx_color?>", shadowSize: 5, data: <?=getFlotArray($hour, 3);?>},
				"hourstx":  {label: "TX, KB", color: "<?=$tx_color?>", shadowSize: 5, data: <?=getFlotArray($hour, 4);?>},
				"daysrx":   {label: "RX, MB", color: "<?=$rx_color?>", shadowSize: 5, data: <?=getFlotArray($day, 3);?>},
				"daystx":   {label: "TX, MB", color: "<?=$tx_color?>", shadowSize: 5, data: <?=getFlotArray($day, 4);?>},				
				"monthsrx": {label: "RX, MB", color: "<?=$rx_color?>", shadowSize: 5, data: <?=getFlotArray($month, 3);?>},
				"monthstx": {label: "TX, MB", color: "<?=$tx_color?>", shadowSize: 5, data: <?=getFlotArray($month, 4);?>},
				"top10rx":  {label: "RX, MB", color: "<?=$rx_color?>", shadowSize: 5, data: <?=getFlotArray($top10, 3, 1);?>},
				"top10tx":  {label: "TX, MB", color: "<?=$tx_color?>", shadowSize: 5, data: <?=getFlotArray($top10, 4, 1);?>}	
			};
			graph_type = "<?=$graph_type?>";
			key = "<?=$time_type?>";
		</script>
	</head>
	<body>
		<div id="leftcolumn">
		<img src="images/logo.png" align="center" style="width:85px;">
		<h3 align="center">KODI</h3>
		<h4 align="center">Media center<br>on Kubuntu</h4><br/><br/>
			<p id="choices">
				<label class="hiddenJS" for="r1"><input class="hiddenJS" type="radio" name="group1" id="r1" value="hours"  <?php if ($time_type == "hours")  {echo "checked";} ?> />Hours&nbsp;&nbsp;&nbsp;</label><br/><br/>
				<label class="hiddenJS" for="r2"><input class="hiddenJS" type="radio" name="group1" id="r2" value="days"   <?php if ($time_type == "days")   {echo "checked";} ?> />Days&nbsp;&nbsp;&nbsp;&nbsp;</label><br/><br/>
				<label class="hiddenJS" for="r3"><input class="hiddenJS" type="radio" name="group1" id="r3" value="months" <?php if ($time_type == "months") {echo "checked";} ?> />Months&nbsp;&nbsp;</label><br/><br/>
				<label class="hiddenJS" for="r4"><input class="hiddenJS" type="radio" name="group1" id="r4" value="top10"  <?php if ($time_type == "top10")  {echo "checked";} ?> />Top&nbsp;10&nbsp;&nbsp;</label><br/><br/>
			</p>
			<br/>		
			<h3>&#11015;&#11014; Total</h3>
			<attr style="color:#FF4500" title="<?=round($info['totalrx'], 0);?> MB">&#11015;RX: <?=number_format($info['totalrx']/1000240, 3);?> TB</attr><br/>
			<attr style="color:#4682B4" title="<?=round($info['totaltx'], 0);?> MB">&#11014;TX: <?=number_format($info['totaltx']/1000024, 3);?> TB</attr><br/>
			<br/>
			<h3>&#9990; Ethernet</h3><?php {echo $interface;} ?><br/><br/>
			<h3>&#9201; Uptime</h3>
			<attr title="System running <?=date($date_format['uptime'], $info['btime'])?>">
				<?=floor((time() - $info['btime']) / 86400);?> days</br>
				<?=floor(((time() - $info['btime']) / 3600) % 24);?> hours</br>
				<?=floor(((time() - $info['btime']) / 60) % 60);?> minutes</attr><br/>
			<br/>
			<h3>&#9923; Database</h3>
			<ins>Created:</ins><br /><?=date("d.m.Y H:i:s", $info['created']);?><br />
			<ins>Last update:</ins><br /><?=date("d.m.Y H:i:s", $info['updated']);?><br />
			<br/>
			<h4><a href="" onclick="window.location.reload(false);">&#8635; Reload DB</a></h4>
			<br/><br />
			<h4 align="left">&#9998; Graph view</h4></br>
			<p id="types">
				<label class="hiddenJS" for="g1"><input class="hiddenJS" type="radio" name="group2" id="g1" value="lines" <?php if ($graph_type == "lines") {echo "checked";} ?> />Lines</label>
				<label class="hiddenJS" for="g2"><input class="hiddenJS" type="radio" name="group2" id="g2" value="bars"  <?php if ($graph_type == "bars")  {echo "checked";} ?> />Bars&nbsp;</label>
			</p>
		</div>
		<div id="content">
		<?php
		if (sizeof($hour) != 24 || sizeof($day) != 30 || sizeof($month) != 12 || sizeof($top10) != 10) { ?>
			<p class="warning">Failed to retrieve data from vnstat!</p><br />
					<small>Ensure that:<br />
					<ul style="margin-left: 30px;">
						<li>vnstat is installed</li>
						<li>vnstat is executable (check php security settings)</li>
						<li>vnstat has a database (if not: vnstat -u -i <?=$interface?>)</li>
					</ul></small>
		<?php } ?>
			<div id="placeholder"></div>
			<br />
			<div id="tables">
			<?=getGraphTable($hour, 'hours', $date_format['hours'], "MB",$precision);?>
			<?=getGraphTable($day, 'days', $date_format['days'], "GB", $precision);?>
			<?=getGraphTable($month, 'months', $date_format['months'], "GB", $precision);?>
			<?=getGraphTable($top10, 'top10', $date_format['top10'], "GB", $precision, 1);?>
			</div>
		</div>
	</body>
</html>

<?php
	function getFlotArray($array2D, $index, $offset = 0) {
		$out = "[";
	    for ($i = 0; $i < sizeof($array2D); ++$i) {
			$out .= "[".($i+$offset).",".$array2D[$i][$index]."],";
		}
		return substr($out, 0, -1)."]";
	}

	function getGraphTable($array2d, $name, $dateformat, $unit, $precision, $offset = 0) {
		$class = '';
		$out = '
		<div id="'.$name.'_table">
			<table class="graph">
				<thead><tr><th>Time</th><th>RX</th><th>TX</th><th>Ratio</th><th>Total</th></tr></thead><tbody>';
					for ($i = 0; $i < sizeof($array2d); ++$i) {
						if (($i % 2) == 1) {$class = "odd";} else {$class="even";}
						$out .= '
						<tr id="'.$name.'_'.($i + $offset).'" class="'.$class.'">';
							if ($array2d[$i][2] != 0) {
								$out .= '<td class="time">'.date($dateformat, $array2d[$i][2]).'</td>';
							} else {
								$out .= '<td class="time">-</td>';
							}
						$out .=	'<td>'.sprintf('%.'.$precision.'f', $array2d[$i][3] / 1024).' '.$unit.'</td>
							<td>'.sprintf('%.'.$precision.'f', $array2d[$i][4] / 1024).' '.$unit.'</td>
							<td>'.sprintf('%.'.$precision.'f', $array2d[$i][4] / ($array2d[$i][3] + 0.001)).'</td>
							<td>'.sprintf('%.'.$precision.'f', ($array2d[$i][3] + $array2d[$i][4]) / 1024).' '.$unit.'</td>
						</tr>';
					}
		$out .= '</tbody>
			</table>
		</div>';
		return $out;
	}

	function getCmdOutput($command) {
		$fd = popen($command, "r");
		$buffer = '';
		while (!feof($fd)) $buffer .= fgets($fd);
		pclose($fd);
		return $buffer;
	}

	function getAvailableInterfaces() {
		$interfaces = explode(": ", getCmdOutput("vnstat --iflist"));
		$interfaces = explode(" ", trim(str_replace('lo', '', $interfaces[1])));
		natsort($interfaces);
		return $interfaces;
	}

	function getFromArgOrCookie($name, $current_value, $acceptable_values) {
		if ($_GET[$name] && in_array($_GET[$name], $acceptable_values)) $value = $_GET[$name];
		else if ($_COOKIE[$name] && in_array($_COOKIE[$name], $acceptable_values)) $value = $_COOKIE[$name];
		else $value = $current_value?$current_value:$acceptable_values[0];
		setcookie($name, $value);
		return $value;
	}
?>