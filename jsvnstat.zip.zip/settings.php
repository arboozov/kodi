<?php
	$interface    = 'enp1s0';		/* Default interface to monitor (e.g. eth0 or wifi0), leave empty for first one */
	$graph_type   = 'lines';		/* Default look of the graph (one of: lines, bars)*/
	$time_type    = 'days';		/* Default time frame (one of: 'hours', 'days', 'months', 'top10') */
	$tx_color     = '#4682B4';		/* TX graph color, default is #00ff00 */
	$rx_color     = '#FF4500';		/* RX graph color, default is #ff0000 */
	$precision    = 2;		    	/* Number of decimal digits to display in table, default is 2 (e.g. 2 = 0.00, 3 = 0.000, etc...) */
	$date_format  = array(   	/* date formats shown in tables and sidebar, see php's date() for reference */
		  'hours' => 'd M H:00',
		  'days'  => 'd.m.Y',
		  'months'=> 'M Y',
		  'top10' => 'd.m.Y',
		  'uptime'=> 'd.m.Y, H:i'
	);
?>
